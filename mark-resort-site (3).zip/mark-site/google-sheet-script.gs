/**
 * Mark Resort – receive leads from the website form into this Google Sheet.
 * Version 4
 */
var SHEET_NAME = 'Leads';
// Paste your Google Sheet ID here (the long text between /d/ and /edit in the sheet's address bar).
var SHEET_ID = '17RmunQtqKJLQiZpOGgwngrkaCuRVGkK6MS4PJ1HJu74';

function clean(v) {
  v = (v == null ? '' : String(v)).slice(0, 1000);
  // stop spreadsheet formula injection
  return /^[=+\-@]/.test(v) ? "'" + v : v;
}

function saveLead_(d) {
  var ss = SHEET_ID ? SpreadsheetApp.openById(SHEET_ID) : SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Time', 'Name', 'Phone', 'Campaign', 'Note', 'Page']);
    sh.setFrozenRows(1);
  }
  var row = sh.getLastRow() + 1;
  sh.getRange(row, 3).setNumberFormat('@');            // phone as text, keeps the leading 0
  sh.getRange(row, 1, 1, 6).setValues([[
    new Date(), clean(d.name), String(d.phone || '').slice(0, 30), clean(d.campaign), clean(d.note), clean(d.page)
  ]]);
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(10000);
  try {
    var d = JSON.parse(e.postData.contents);
    saveLead_(d);
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    console.error('doPost failed: ' + err);
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

// Open  <your /exec URL>?test=1  in the browser to write a test row and see the result.
function doGet(e) {
  if (e && e.parameter && e.parameter.test) {
    try {
      saveLead_({ name: 'Test', phone: '01000000000', note: 'browser test', campaign: 'Test', page: 'doGet-test' });
      return ContentService.createTextOutput('OK v4 – a test row was written to the "' + SHEET_NAME + '" tab.');
    } catch (err) {
      return ContentService.createTextOutput('ERROR v4 – ' + String(err));
    }
  }
  return ContentService.createTextOutput('Mark Resort leads endpoint v4 is running.');
}

// Run this from the editor to test (select testWrite, click Run).
function testWrite() {
  saveLead_({ name: 'Test', phone: '01000000000', note: 'test', campaign: 'Test', page: 'editor' });
  Logger.log('written');
}
